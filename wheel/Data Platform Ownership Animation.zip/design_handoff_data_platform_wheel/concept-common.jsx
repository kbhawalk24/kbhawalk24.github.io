const { CompositionStage, useComposition, Easing, clamp, useTweaks, TweaksPanel, TweakSection, TweakToggle } = window;

const prog = (T, s, d) => clamp((T - s) / d, 0, 1);
const DP = {
  C: { green: '#167F5F', purple: '#6B2BD9', orange: '#B5541B', ink: '#16141C', mute: '#6F6C78', empty: '#ECEBF0', bg: '#FAFAFC' },
  SANS: "'Nunito Sans', 'Helvetica Neue', Helvetica, sans-serif",
  MONO: "'IBM Plex Mono', ui-monospace, monospace",
  STAGES: ['Produce & instrument', 'Move & ingest', 'Store & persist', 'Discover & access', 'Process & derive', 'Test & quality', 'Consume & activate'],
  ROLES: {
    designed: { label: 'Designed hands-on', tag: '2021–24', color: '#167F5F', f: [0, 0, 0, 1, 0, 0, 1] },
    manager: { label: 'Led as design manager', tag: '2024–26', color: '#6B2BD9', f: [1, 1, 0, 1, 1, 1, 1] },
    clean: { label: 'Clean-data standard', tag: 'Strategy', color: '#B5541B', f: [1, 0, 0, 1, 0, 1, 1] },
    access: { label: 'Fine-grained access control', tag: 'Strategy', color: '#B5541B', f: [1, 1, 1, 1, 1, 1, 1] },
  },
  prog,
  MOTION: {
    enter: (T, s, d = 0.6) => Easing.easeOutCubic(prog(T, s, d)),
    draw: (T, s, d = 0.6) => Easing.easeInOutCubic(prog(T, s, d)),
    pop: (T, s, d = 0.5) => Math.sin(Math.PI * prog(T, s, d)),
  },
  // fade in at s, fade out at e
  window: (T, s, e, d = 0.5) => DP.MOTION.enter(T, s, d) * (1 - DP.MOTION.enter(T, e - d * 0.5, d)),
  BG: 'radial-gradient(1200px 700px at 100% 0%, #F1EFF8 0%, rgba(241,239,248,0) 70%), radial-gradient(900px 600px at 0% 100%, #EFEDF7 0%, rgba(239,237,247,0) 70%), #FAFAFC',
};

function DPFrame({ children }) {
  const { T, time, authoredTotal } = useComposition();
  const fade = 1 - DP.MOTION.enter(T, authoredTotal - 0.9, 0.8);
  return (
    <div data-screen-label={`t=${Math.floor(time)}s`} style={{ position: 'absolute', inset: 0, fontFamily: DP.SANS, color: DP.C.ink, overflow: 'hidden', background: DP.BG }}>
      <div style={{ position: 'absolute', inset: 0, opacity: fade }}>{children}</div>
    </div>
  );
}

function DPTitle({ T, CUES, a, b, top = 90 }) {
  const aIn = DP.MOTION.enter(T, 0.2, 0.8), aOut = DP.MOTION.enter(T, CUES.Summary + 0.2, 0.5), bIn = DP.MOTION.enter(T, CUES.Summary + 0.6, 0.8);
  const st = { position: 'absolute', left: 100, right: 100, top, fontSize: 46, fontWeight: 800, letterSpacing: '-0.01em' };
  return (
    <>
      <div style={{ ...st, opacity: aIn * (1 - aOut), transform: `translateY(${(1 - aIn) * 18}px)` }}>{a}</div>
      <div style={{ ...st, opacity: bIn, transform: `translateY(${(1 - bIn) * 18}px)` }}>{b}</div>
    </>
  );
}

function DPShell({ Piece }) {
  const [t, setTweak] = useTweaks(window.TWEAK_DEFAULTS);
  return (
    <>
      <CompositionStage width={1920} height={1080} scenes={window.OM_SCENES} playback={window.OM_PLAYBACK} bg={DP.C.bg}>
        <Piece t={t} />
      </CompositionStage>
      <TweaksPanel>
        <TweakSection label="Playback" />
        <TweakToggle label="Motion editor" value={t.motionEditor} onChange={(v) => setTweak('motionEditor', v)} />
        {'dimOthers' in (window.TWEAK_DEFAULTS || {}) && <TweakToggle label="Dim stages not in focus" value={t.dimOthers} onChange={(v) => setTweak('dimOthers', v)} />}
      </TweaksPanel>
    </>
  );
}

DP.PSTAGES = [
  { t: 'Produce & instrument data', p: ['Data product scoring and certification', 'Data Map authoring', 'Guided source onboarding'] },
  { t: 'Move & ingest data', p: ['Batch ingestion', 'Real-time stream materialization'] },
  { t: 'Store & persist data', p: [], d: 'Entity storage, managed databases, event bus' },
  { t: 'Discover & access data', p: ['Catalog and search', 'Data Map', 'Plain-language assistant', 'Lineage', 'Access requests and control', 'Collections', 'Agent in Cursor and Claude'] },
  { t: 'Process & derive data', p: ['Pipeline authoring, batch and stream'] },
  { t: 'Test & ensure data quality', p: ['Data quality checks', 'Reliability and monitoring'] },
  { t: 'Consume & activate data', p: ['Self-service marketing data onboarding', 'BI dashboards'] },
];
DP.STRATEGY = { label: 'Set platform strategy', color: '#B5541B', f: [1, 1, 1, 1, 1, 1, 1], items: ['Clean-data standard', 'Fine-grained access control'] };
DP.owner = (i) => (DP.ROLES.designed.f[i] ? 0 : DP.ROLES.manager.f[i] ? 1 : -1);

function DPProducts({ T, s, start, color, align = 'left' }) {
  const { MOTION, C } = DP;
  return (
    <>
      {s.d && <div style={{ fontSize: 17, lineHeight: 1.3, color: C.mute }}>{s.d}</div>}
      {s.p.map((pr, k) => {
        const q = start == null ? 0 : MOTION.enter(T, start + k * 0.1, 0.5);
        return (
          <div key={k} style={{ display: 'flex', alignItems: 'center', gap: 8, flexDirection: align === 'right' ? 'row-reverse' : 'row', fontSize: 17, lineHeight: 1.3, opacity: q, transform: `translateY(${(1 - q) * 8}px)` }}>
            <div style={{ width: 8, height: 8, borderRadius: 2, background: color, flexShrink: 0 }}></div>{pr}
          </div>
        );
      })}
    </>
  );
}

Object.assign(window, { DP, DPFrame, DPTitle, DPShell, DPProducts });
