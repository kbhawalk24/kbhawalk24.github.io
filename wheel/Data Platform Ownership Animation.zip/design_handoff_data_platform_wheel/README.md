# Handoff: Data Platform Ownership — Lifecycle Wheel animation

## Overview
A ~25.5s looping 16:9 motion graphic for a design-leadership portfolio. It explains, at a glance, what the designer designed hands-on, led as design manager, and set strategy for across the seven stages of Intuit's data platform lifecycle (2021–2026).

## About the Design Files
The files here are **design references built in HTML** — a working prototype of the intended look and motion, not production code to ship. Recreate it in the portfolio's existing stack (e.g. React/Next + Framer Motion/GSAP, or plain SVG + CSS/WAAPI). If the portfolio has no framework, a single self-contained React component or vanilla SVG+JS module is appropriate.

Open `Concept D Wheel v2.dc.html` in a browser to watch the reference (it loads the `.jsx` files beside it). The authored source of truth is `concept-wheel-v2.jsx` (layout + choreography) and `concept-common.jsx` (data, colors, easing helpers). `animations-v3.jsx` and `tweaks-panel.jsx` are prototype tooling (timeline engine, editor panel) — do NOT port them.

Alternative delivery: export an MP4 from the prototype (Share → Export → Video) and embed it as `<video autoplay muted loop playsinline>`. Recreating in code is preferred for crisp scaling and accessibility.

## Fidelity
**High-fidelity.** Recreate colors, type, geometry and timing as specified.

## Canvas
- 1920×1080 artboard, scale uniformly to fit container (keep 16:9). Background `#FAFAFC` with two soft radial glows: `radial-gradient(1200px 700px at 100% 0%, #F1EFF8, transparent 70%)`, `radial-gradient(900px 600px at 0% 100%, #EFEDF7, transparent 70%)`.
- Fonts: **Nunito Sans** (400/600/700/800), **IBM Plex Mono** (400) — Google Fonts.

## Layout (artboard px)
- **Title**: left 100, top 70, Nunito Sans 800, 46px, letter-spacing −0.01em, color `#16141C`.
  - Opening text: "Led design and strategy for Intuit’s data platform"
  - Summary text (crossfades in): "Designed it. Led it. Set the strategy."
- **Wheel**: center (760, 600). 7 equal segments (2π/7), gap 0.035 rad trimmed from each segment end. Rotated so stage 4 is centered at 3 o'clock: segment i spans `start + i·seg` → `start + (i+1)·seg`, where `start = −3.5·seg`. Stage 1 lands upper-left; order runs clockwise.
- **Three rings** (SVG arc strokes, width 38, butt caps). Empty track color `#ECEBF0`.
  | Ring | Radius | Color | Stages filled (1–7) |
  |---|---|---|---|
  | Designed hands-on (2021–24) | 170 | `#167F5F` | 4, 7 |
  | Led as design manager (2024–26) | 225 | `#6B2BD9` | 1, 2, 4, 5, 6, 7 |
  | Set platform strategy | 280 | `#B5541B` | all 7 |
- **Center label**: "The data lifecycle", 22px, `#6F6C78`, centered on wheel.
- **Stage labels**: positioned at radius 330 from center along each segment's mid-angle; box width 310. Anchor: if cos(angle) > 0.3 → left-aligned, box starts at point; < −0.3 → right-aligned, box ends at point; else centered. Vertically: sin < −0.6 → box bottom at point; sin > 0.6 → box top at point; else centered. Column flex, gap 4.
  - Heading: mono stage number (IBM Plex Mono 16px, `#6F6C78`, margin-right 8) + name, Nunito Sans 800 22px, line-height 1.2.
  - Products: 17px/1.3, `#16141C`, each preceded by an 8×8 square (radius 2) — green `#167F5F` if the stage was designed hands-on, purple `#6B2BD9` otherwise. Row reversed on right-aligned labels.
- **Legend** (right): left 1450, top 330, width 400, column gap 40. Each item: 20×20 swatch (radius 5) + label Nunito Sans 700 32px/1.15 + optional mono tag (17px uppercase, letter-spacing 0.08em, `#6F6C78`). Strategy item lists two initiatives below (22px 600, gap 10).

## Content
| # | Stage | Products |
|---|---|---|
| 1 | Produce & instrument data | Data product scoring and certification · Data Map authoring · Guided source onboarding |
| 2 | Move & ingest data | Batch ingestion · Real-time stream materialization |
| 3 | Store & persist data | (none — shows muted description: "Entity storage, managed databases, event bus") |
| 4 | Discover & access data | Catalog and search · Data Map · Plain-language assistant · Lineage · Access requests and control · Collections · Agent in Cursor and Claude |
| 5 | Process & derive data | Pipeline authoring, batch and stream |
| 6 | Test & ensure data quality | Data quality checks · Reliability and monitoring |
| 7 | Consume & activate data | Self-service marketing data onboarding · BI dashboards |

Legend: "Designed hands-on" (tag 2021–24) · "Led as design manager" (tag 2024–26) · "Set platform strategy" → "Clean-data standard", "Fine-grained access control".

## Timeline (seconds, loops)
Scene starts: Opening 0 · Lifecycle 2.5 · Designed 5.5 · Manager 10.5 · Strategy 16 · Summary 20.5 · end 25.

Easing helpers (use only these):
- `enter` = easeOutCubic — fades/slides (default 0.6s)
- `draw` = easeInOutCubic — arc fills (0.5s)
- `pop` = sin(π·p) bump (0.5s)

Choreography:
- 0.2–1.0 title fades in, rising 18px.
- Lifecycle: each stage i (track arcs + label) fades in at 2.5 + 0.2·i over 0.6s. Center label in at 4.1.
- Each ring: legend item slides in (24px from right) at ringStart − 0.8; filled arcs draw from segment start to end, staggered 0.16s per filled stage, starting at Designed+0.8 (6.3), Manager+0.8 (11.3), Strategy+0.6 (16.6).
- Products: designed stages appear at 6.9, managed stages at 12.1; items stagger 0.1s, fade + rise 8px.
- Strategy initiatives appear at 17.4 and 17.7.
- Focus: the active ring and its legend item are full opacity; others drop to 0.35 (arcs) / 0.4 (legend). In Summary all return to full.
- Summary: title A out at 20.7 (0.5s), title B in at 21.1 (0.8s).
- Last 0.9s: whole composition fades to empty, so the loop seam matches frame 0.

## Accessibility / responsive
- Respect `prefers-reduced-motion`: show the final (Summary) frame statically.
- Provide an accessible text alternative (the content table above) via `aria-label` or visually hidden list.
- Below ~900px wide, consider a static image or the stacked table instead of the wheel.

## Design Tokens
- Ink `#16141C`, muted `#6F6C78`, empty track `#ECEBF0`, background `#FAFAFC`
- Green `#167F5F`, purple `#6B2BD9`, orange `#B5541B`

## Files
- `Concept D Wheel v2.dc.html` — reference entry (open in browser; needs `support.js` + jsx files beside it)
- `concept-wheel-v2.jsx` — wheel layout + choreography (source of truth)
- `concept-common.jsx` — data, colors, easing, title/frame helpers
- `animations-v3.jsx`, `tweaks-panel.jsx`, `support.js` — prototype tooling only
