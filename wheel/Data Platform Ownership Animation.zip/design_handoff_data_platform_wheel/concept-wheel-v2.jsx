// Concept D v2 — lifecycle wheel, 3 rings (designed / led / strategy), products around the wheel
function arc(cx, cy, r, a0, a1) {
  const p = (a) => [cx + r * Math.cos(a), cy + r * Math.sin(a)];
  const [x0, y0] = p(a0), [x1, y1] = p(a1);
  return `M${x0} ${y0} A${r} ${r} 0 ${a1 - a0 > Math.PI ? 1 : 0} 1 ${x1} ${y1}`;
}
const W_STAGES = [
  { t: 'Produce & instrument data', p: ['Data product scoring and certification', 'Data Map authoring', 'Guided source onboarding'] },
  { t: 'Move & ingest data', p: ['Batch ingestion', 'Real-time stream materialization'] },
  { t: 'Store & persist data', p: [], d: 'Entity storage, managed databases, event bus' },
  { t: 'Discover & access data', p: ['Catalog and search', 'Data Map', 'Plain-language assistant', 'Lineage', 'Access requests and control', 'Collections', 'Agent in Cursor and Claude'] },
  { t: 'Process & derive data', p: ['Pipeline authoring, batch and stream'] },
  { t: 'Test & ensure data quality', p: ['Data quality checks', 'Reliability and monitoring'] },
  { t: 'Consume & activate data', p: ['Self-service marketing data onboarding', 'BI dashboards'] },
];

function WheelPiece({ t }) {
  const { T, CUES } = useComposition();
  const { C, MOTION, ROLES, MONO } = DP;
  const cx = 760, cy = 600, seg = (Math.PI * 2) / 7, gap = 0.035;
  const start = -3 * seg - seg / 2; // stage 4 (Discover) sits at 3 o'clock
  const strategy = { label: 'Set platform strategy', tag: 'every stage', color: C.orange, f: [1, 1, 1, 1, 1, 1, 1] };
  const rings = [
    { r: ROLES.designed, rad: 170, s: CUES.Designed + 0.8, e: CUES.Manager, tag: '2021–24' },
    { r: ROLES.manager, rad: 225, s: CUES.Manager + 0.8, e: CUES.Strategy, tag: '2024–26' },
    { r: strategy, rad: 280, s: CUES.Strategy + 0.6, e: CUES.Summary, tag: null },
  ];
  const summary = MOTION.enter(T, CUES.Summary + 0.2, 0.6);
  const wheelIn = (i) => MOTION.enter(T, CUES.Lifecycle + i * 0.2, 0.6);
  const focus = (k) => Math.max(DP.window(T, rings[k].s - 0.8, rings[k].e), summary);
  const owner = (i) => (ROLES.designed.f[i] ? 0 : ROLES.manager.f[i] ? 1 : -1);
  const initiatives = [
    { name: 'Clean-data standard', s: CUES.Strategy + 1.4 },
    { name: 'Fine-grained access control', s: CUES.Strategy + 1.7 },
  ];
  return (
    <DPFrame>
      <DPTitle T={T} CUES={CUES} a="Led design and strategy for Intuit’s data platform" b="Designed it. Led it. Set the strategy." top={70} />
      <svg width="1920" height="1080" style={{ position: 'absolute', inset: 0 }}>
        {W_STAGES.map((_, i) => {
          const a0 = start + i * seg + gap, a1 = start + (i + 1) * seg - gap;
          return rings.map((g, k) => <path key={i + '-' + k} d={arc(cx, cy, g.rad, a0, a1)} stroke={C.empty} strokeWidth="38" fill="none" opacity={wheelIn(i)} />);
        })}
        {rings.map((g, k) => {
          let n = 0;
          return W_STAGES.map((_, i) => {
            if (!g.r.f[i]) return null;
            const a0 = start + i * seg + gap, a1 = start + (i + 1) * seg - gap;
            const p = MOTION.draw(T, g.s + (n++) * 0.16, 0.5);
            if (p <= 0) return null;
            return <path key={k + '-' + i} d={arc(cx, cy, g.rad, a0, a0 + (a1 - a0) * Math.max(p, 0.001))} stroke={g.r.color} strokeWidth="38" fill="none" opacity={0.35 + 0.65 * focus(k)} />;
          });
        })}
      </svg>
      {W_STAGES.map((s, i) => {
        const a = start + (i + 0.5) * seg, R = 330, cs = Math.cos(a), sn = Math.sin(a);
        const hx = cs > 0.3 ? 0 : cs < -0.3 ? -100 : -50, vy = sn < -0.6 ? -100 : sn > 0.6 ? 0 : -50;
        const align = cs > 0.3 ? 'left' : cs < -0.3 ? 'right' : 'center';
        const p = wheelIn(i), o = owner(i);
        const ps = o === 0 ? CUES.Designed + 1.4 : o === 1 ? CUES.Manager + 1.6 : null;
        const col = o === 0 ? C.green : C.purple;
        return (
          <div key={i} style={{ position: 'absolute', left: cx + R * cs, top: cy + R * sn, width: 310, transform: `translate(${hx}%, ${vy}%)`, textAlign: align, opacity: p, display: 'flex', flexDirection: 'column', alignItems: align === 'left' ? 'flex-start' : align === 'right' ? 'flex-end' : 'center', gap: 4 }}>
            <div style={{ fontSize: 22, fontWeight: 800, lineHeight: 1.2, marginBottom: 4 }}><span style={{ fontFamily: MONO, fontSize: 16, fontWeight: 400, color: C.mute, marginRight: 8 }}>{i + 1}</span>{s.t}</div>
            {s.d && <div style={{ fontSize: 17, lineHeight: 1.3, color: C.mute }}>{s.d}</div>}
            {s.p.map((pr, k) => {
              const q = ps == null ? 0 : MOTION.enter(T, ps + k * 0.1, 0.5);
              return (
                <div key={k} style={{ display: 'flex', alignItems: 'center', gap: 8, flexDirection: align === 'right' ? 'row-reverse' : 'row', fontSize: 17, lineHeight: 1.3, opacity: q, transform: `translateY(${(1 - q) * 8}px)` }}>
                  <div style={{ width: 8, height: 8, borderRadius: 2, background: col, flexShrink: 0 }}></div>{pr}
                </div>
              );
            })}
          </div>
        );
      })}
      <div style={{ position: 'absolute', left: cx - 110, top: cy - 30, width: 220, textAlign: 'center', fontSize: 22, color: C.mute, opacity: MOTION.enter(T, CUES.Lifecycle + 1.6, 0.6) }}>The data lifecycle</div>
      <div style={{ position: 'absolute', left: 1450, top: 330, width: 400, display: 'flex', flexDirection: 'column', gap: 40 }}>
        {rings.map((g, k) => {
          const shown = MOTION.enter(T, g.s - 0.8, 0.6), f = focus(k);
          return (
            <div key={k} style={{ display: 'flex', gap: 18, alignItems: 'flex-start', opacity: shown * (0.4 + 0.6 * f), transform: `translateX(${(1 - shown) * 24}px)` }}>
              <div style={{ width: 20, height: 20, borderRadius: 5, background: g.r.color, marginTop: 9, flexShrink: 0 }}></div>
              <div>
                <div style={{ fontSize: 32, fontWeight: 700, lineHeight: 1.15 }}>{g.r.label}</div>
                {g.tag && <div style={{ fontFamily: MONO, fontSize: 17, color: C.mute, letterSpacing: '0.08em', textTransform: 'uppercase', marginTop: 6 }}>{g.tag}</div>}
                {k === 2 && (
                  <div style={{ display: 'flex', flexDirection: 'column', gap: 10, marginTop: 16 }}>
                    {initiatives.map((n, j) => {
                      const q = MOTION.enter(T, n.s, 0.5);
                      return (
                        <div key={j} style={{ opacity: q, transform: `translateY(${(1 - q) * 10}px)` }}>
                          <div style={{ fontSize: 22, fontWeight: 600 }}>{n.name}</div>
                        </div>
                      );
                    })}
                  </div>
                )}
              </div>
            </div>
          );
        })}
      </div>
    </DPFrame>
  );
}
window.WheelAppV2 = () => <DPShell Piece={WheelPiece} />;
